## GECCO Core Data

